"""Scripts package for command-line utilities (seed, data checks, etc.).

Allows invoking as a module: python -m scripts.seed
"""

from . import seed  # noqa: F401  (re-export optional convenience)