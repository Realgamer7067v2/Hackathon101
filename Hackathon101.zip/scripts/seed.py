"""Seed script for sample data.

Recommended invocation (ensures proper package resolution):
    python -m scripts.seed --force --yes

Fallback direct invocation (adds project root to sys.path automatically):
    python scripts/seed.py --force --yes
"""
from __future__ import annotations
import argparse
import sys

# --- Path bootstrap -------------------------------------------------------
# When run as a standalone file (python scripts/seed.py) __package__ is None
# and relative imports fail. We inject the project root (parent of scripts/)
# into sys.path so that 'app' package resolves. Using -m scripts.seed avoids
# this, but we make the direct execution path robust for convenience.
if __package__ is None or __package__ == '':  # pragma: no cover (environmental)
    import pathlib, os  # noqa: WPS433 (local import intentional)
    project_root = pathlib.Path(__file__).resolve().parents[1]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

from app.storage import csv_storage as store
from app.auth.utils import hash_password
import random
import itertools

SAMPLE_ORGS = [
    {"name":"Green Earth","email":"green@example.org","description":"Environmental NGO","needs":"Volunteers for cleanup","latitude":"37.7749","longitude":"-122.4194"},
    {"name":"Health Help","email":"health@example.org","description":"Community health support","needs":"Clinic assistance","latitude":"34.0522","longitude":"-118.2437"},
]

SAMPLE_OPPORTUNITIES = [
    {"title":"Park Cleanup Drive","description":"Help clean local park","required_skills":"teamwork,physical","tags":"environment,cleanup","schedule":"Weekends","latitude":"37.7749","longitude":"-122.4194"},
    {"title":"Community Clinic Support","description":"Assist with patient intake","required_skills":"organization,communication","tags":"health,logistics","schedule":"Weekdays","latitude":"34.0522","longitude":"-118.2437"},
    {"title":"After-school Tutoring","description":"Tutor students in math and reading","required_skills":"teaching,patience","tags":"education,children","schedule":"Weekdays afternoon","latitude":"40.7128","longitude":"-74.0060"},
    {"title":"Food Bank Sorting","description":"Sort and pack food donations","required_skills":"organization","tags":"logistics,community","schedule":"Flexible","latitude":"41.8781","longitude":"-87.6298"},
    {"title":"Community Art Workshop","description":"Assist in organizing art sessions","required_skills":"art,creativity","tags":"arts,education","schedule":"Weekends","latitude":"29.7604","longitude":"-95.3698"},
]

# ---------------- Rich Dataset Definitions ------------------
RICH_ORGS = [
    {"name":"Urban Garden Collective","email":"garden@ugc.org","description":"Neighborhood urban agriculture & food access","needs":"Volunteer coordinators, compost team","latitude":"40.7128","longitude":"-74.0060"},
    {"name":"Metro Literacy Alliance","email":"literacy@mla.org","description":"Adult literacy & ESL tutoring","needs":"Evening tutors","latitude":"34.0522","longitude":"-118.2437"},
    {"name":"Harbor Wildlife Rescue","email":"wildlife@harborwr.org","description":"Rescue & rehabilitate injured coastal wildlife","needs":"Transport, intake triage","latitude":"47.6062","longitude":"-122.3321"},
    {"name":"Community Health Outreach","email":"outreach@cho.org","description":"Preventative screenings & health education","needs":"Bilingual outreach staff","latitude":"41.8781","longitude":"-87.6298"},
    {"name":"STEM Spark Foundation","email":"stem@sparksf.org","description":"STEM mentoring for underserved youth","needs":"Mentor onboarding","latitude":"37.7749","longitude":"-122.4194"},
    {"name":"Art Bridge Initiative","email":"hello@artbridge.io","description":"Art therapy & creative workshops","needs":"Session co-facilitators","latitude":"29.7604","longitude":"-95.3698"},
]

RICH_VOLUNTEERS = [
    {"name":"Ava Patel","email":"ava.patel@example.com","skills":"teaching,communication,organization","interests":"education,community","availability":"weeknights","latitude":"40.7306","longitude":"-73.9352"},
    {"name":"Marcus Lee","email":"marcus.lee@example.com","skills":"first-aid,logistics,teamwork","interests":"health,environment","availability":"weekends","latitude":"34.0407","longitude":"-118.2468"},
    {"name":"Sofia Hernandez","email":"sofia.h@example.com","skills":"bilingual,communication,outreach","interests":"health,education","availability":"flexible","latitude":"41.8853","longitude":"-87.6229"},
    {"name":"Ethan Chen","email":"ethan.chen@example.com","skills":"python,data,analysis","interests":"education,technology","availability":"weekdays","latitude":"37.7810","longitude":"-122.4112"},
    {"name":"Jamal Brown","email":"jamal.brown@example.com","skills":"mentoring,teaching,teamwork","interests":"youth,education","availability":"weekends","latitude":"29.7520","longitude":"-95.3700"},
    {"name":"Lena Kovacs","email":"lena.kovacs@example.com","skills":"art,creativity,facilitation","interests":"arts,community","availability":"evenings","latitude":"47.6101","longitude":"-122.3421"},
    {"name":"Priya Singh","email":"priya.singh@example.com","skills":"fundraising,organization,communication","interests":"community,environment","availability":"flexible","latitude":"40.7210","longitude":"-73.9950"},
    {"name":"Noah Williams","email":"noah.williams@example.com","skills":"physical,teamwork,coordination","interests":"environment,logistics","availability":"weekends","latitude":"34.0600","longitude":"-118.3000"},
]

RICH_OPPORTUNITIES = [
    {"title":"Saturday Garden Build Crew","description":"Assist with constructing raised beds and irrigation setup.","required_skills":"physical,teamwork","tags":"environment,community","schedule":"Saturday mornings","latitude":"40.7132","longitude":"-74.0009","org_ref":0},
    {"title":"ESL Evening Tutor","description":"Support adult learners with conversational English.","required_skills":"teaching,communication","tags":"education,language","schedule":"Tue/Thu 6-8pm","latitude":"34.0400","longitude":"-118.2500","org_ref":1},
    {"title":"Wildlife Intake Assistant","description":"Assist with triage forms and basic stabilization.","required_skills":"first-aid,organization","tags":"environment,rescue","schedule":"Flexible shifts","latitude":"47.6065","longitude":"-122.3350","org_ref":2},
    {"title":"Mobile Health Screening Support","description":"Set up stations and guide visitors through screening process.","required_skills":"logistics,communication","tags":"health,community","schedule":"Sat/Sun events","latitude":"41.8800","longitude":"-87.6300","org_ref":3},
    {"title":"STEM Robotics Mentor","description":"Mentor middle-school students building simple robots.","required_skills":"teaching,mentoring","tags":"education,technology","schedule":"Weds 4-6pm","latitude":"37.7790","longitude":"-122.4180","org_ref":4},
    {"title":"Creative Arts Workshop Co-Facilitator","description":"Co-lead therapeutic art sessions; prep materials.","required_skills":"art,creativity,facilitation","tags":"arts,therapy","schedule":"Weekday evenings","latitude":"29.7608","longitude":"-95.3650","org_ref":5},
    {"title":"Data Cleanup & Impact Dashboard","description":"Normalize historical volunteer sign-in sheets into structured CSV.","required_skills":"data,organization","tags":"technology,analysis","schedule":"Remote flexible","latitude":"37.7740","longitude":"-122.4200","org_ref":4},
    {"title":"Garden Compost Operations","description":"Turn compost piles, monitor temperature logs.","required_skills":"physical,teamwork","tags":"environment,sustainability","schedule":"Sunday mornings","latitude":"40.7142","longitude":"-74.0050","org_ref":0},
    {"title":"Health Outreach Bilingual Caller","description":"Call community members with screening reminders (Spanish/English).","required_skills":"bilingual,communication","tags":"health,outreach","schedule":"Weekday evenings","latitude":"41.8820","longitude":"-87.6280","org_ref":3},
    {"title":"Fundraising Research Assistant","description":"Identify small grant opportunities & summarize criteria.","required_skills":"research,fundraising","tags":"community,development","schedule":"Remote flexible","latitude":"40.7160","longitude":"-74.0020","org_ref":0},
]

def seed_rich():
    print('Seeding rich dataset...')
    # Initialize files
    for n in store.DATASETS:
        store.safe_init(n)
    if store.read_rows('organizations'):
        print('Data already present; abort (use --force).')
        return
    # Orgs
    for org in RICH_ORGS:
        rows = store.read_rows('organizations')
        oid = store.next_id(rows)
        store.append_row('organizations', {
            'id': oid,
            'name': org['name'],
            'email': org['email'],
            'password_hash': hash_password('password'),
            'description': org['description'],
            'needs': org['needs'],
            'latitude': org['latitude'],
            'longitude': org['longitude'],
            'verified': '1'
        })
    orgs = store.read_rows('organizations')
    # Volunteers
    for vol in RICH_VOLUNTEERS:
        rows = store.read_rows('volunteers')
        vid = store.next_id(rows)
        store.append_row('volunteers', {
            'id': vid,
            'name': vol['name'],
            'email': vol['email'],
            'password_hash': hash_password('password'),
            'skills': vol['skills'],
            'interests': vol['interests'],
            'availability': vol['availability'],
            'latitude': vol['latitude'],
            'longitude': vol['longitude'],
        })
    # Opportunities
    for opp in RICH_OPPORTUNITIES:
        rows = store.read_rows('opportunities')
        oid = store.next_id(rows)
        org_id = orgs[opp['org_ref']]['id']
        store.append_row('opportunities', {
            'id': oid,
            'org_id': org_id,
            'title': opp['title'],
            'description': opp['description'],
            'required_skills': opp['required_skills'],
            'tags': opp['tags'],
            'schedule': opp['schedule'],
            'latitude': opp['latitude'],
            'longitude': opp['longitude'],
            'created_at': store.timestamp(),
        })
    # Sample applications with initial messages for first few volunteers
    volunteers = store.read_rows('volunteers')
    opportunities = store.read_rows('opportunities')
    for vol in volunteers[:4]:
        # pick two opportunities somewhat near (simple slice) deterministic
        for opp in opportunities[:3]:
            apps = store.read_rows('applications')
            if any(a.get('opportunity_id') == opp['id'] and a.get('volunteer_id') == vol['id'] for a in apps):
                continue
            app_id = store.next_id(apps)
            message = f"Hi, I'm {vol['name'].split()[0]} and interested in contributing." if random.random() < 0.6 else ''
            store.append_row('applications', {
                'id': app_id,
                'opportunity_id': opp['id'],
                'volunteer_id': vol['id'],
                'status': 'pending',
                'message': message,
                'created_at': store.timestamp(),
            })
            if message:
                threads = store.read_rows('threads')
                t_id = store.next_id(threads)
                store.append_row('threads', {
                    'id': t_id,
                    'opportunity_id': opp['id'],
                    'volunteer_id': vol['id'],
                    'org_id': opp['org_id'] if 'org_id' in opp else next((o['org_id'] for o in opportunities if o['id']==opp['id']), ''),
                    'created_at': store.timestamp(),
                    'updated_at': store.timestamp(),
                })
                messages = store.read_rows('messages')
                m_id = store.next_id(messages)
                store.append_row('messages', {
                    'id': m_id,
                    'thread_id': t_id,
                    'sender_type': 'volunteer',
                    'sender_id': vol['id'],
                    'receiver_type': 'organization',
                    'receiver_id': opp['org_id'] if 'org_id' in opp else '',
                    'body': message,
                    'created_at': store.timestamp(),
                })
    print('Rich seed complete.')

def wipe():
    for name in ('volunteers','organizations','opportunities','applications','threads','messages'):
        path = store.file_path(name)
        try:
            import os
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass


def seed():
    for n in store.DATASETS:
        store.safe_init(n)
    org_rows = store.read_rows('organizations')
    if org_rows:
        print('Organizations already exist; aborting (use --force).')
        return
    # add orgs
    for org in SAMPLE_ORGS:
        org_rows = store.read_rows('organizations')
        oid = store.next_id(org_rows)
        row = {
            'id': oid,
            'name': org['name'],
            'email': org['email'],
            'password_hash': hash_password('password'),
            'description': org['description'],
            'needs': org['needs'],
            'latitude': org['latitude'],
            'longitude': org['longitude'],
            'verified': '1'
        }
        store.append_row('organizations', row)
    # opportunities cycle org ids
    orgs = store.read_rows('organizations')
    for opp in SAMPLE_OPPORTUNITIES:
        opp_rows = store.read_rows('opportunities')
        oid = opp_rows[0]['org_id'] if opp_rows else orgs[0]['id']
        # rotate
        oid = orgs[len(opp_rows) % len(orgs)]['id']
        oid_rows = store.read_rows('opportunities')
        opp_id = store.next_id(oid_rows)
        row = {
            'id': opp_id,
            'org_id': oid,
            'title': opp['title'],
            'description': opp['description'],
            'required_skills': opp['required_skills'],
            'tags': opp['tags'],
            'schedule': opp['schedule'],
            'latitude': opp['latitude'],
            'longitude': opp['longitude'],
            'created_at': store.timestamp(),
        }
        store.append_row('opportunities', row)
    print('Seed complete.')


def main(argv=None):
    parser = argparse.ArgumentParser(description='Seed CSV data with sample or rich dataset.')
    parser.add_argument('--force', action='store_true', help='Wipe existing data before seeding')
    parser.add_argument('--yes', action='store_true', help='Assume yes when wiping')
    parser.add_argument('--rich', action='store_true', help='Seed a richer, more realistic dataset')
    args = parser.parse_args(argv)
    if args.force:
        if not args.yes:
            resp = input('This will delete existing data. Continue? [y/N] ')
            if resp.lower() != 'y':
                print('Aborted.')
                return
        wipe()
    if args.rich:
        seed_rich()
    else:
        seed()

if __name__ == '__main__':
    main()
