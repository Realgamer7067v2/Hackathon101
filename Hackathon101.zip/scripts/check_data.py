"""Simple data quality check script."""
from app.storage import csv_storage as store

def main():
    for name, fields in store.DATASETS.items():
        rows = store.read_rows(name)
        if rows:
            missing = [f for f in fields if f not in rows[0]]
            if missing:
                print(f"{name}: MISSING headers {missing}")
            else:
                print(f"{name}: OK ({len(rows)} rows)")
        else:
            print(f"{name}: empty (headers ensured)")

if __name__ == '__main__':
    main()
