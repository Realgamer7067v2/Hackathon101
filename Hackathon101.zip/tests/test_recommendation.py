import os
from app.services.recommendation import compute_recommendations
from app.storage import csv_storage as store
from app.auth.utils import hash_password


def setup_module(module):  # simplistic fixture
    os.makedirs('data', exist_ok=True)
    # clear datasets
    for name in ('volunteers','organizations','opportunities'):
        path = store.file_path(name)
        if os.path.exists(path):
            os.remove(path)
    for n in store.DATASETS:
        store.safe_init(n)
    # volunteer
    store.append_row('volunteers', {
        'id':'1','name':'V','email':'v@example.com','password_hash':hash_password('p'),
        'skills':'teaching math','interests':'education children','availability':'weekdays','latitude':'40.0','longitude':'-75.0'
    })
    # opportunity near but partial
    store.append_row('opportunities', {
        'id':'1','org_id':'1','title':'Math Tutor','description':'help students','required_skills':'teaching math','tags':'education','schedule':'weekdays','latitude':'40.1','longitude':'-75.1','created_at':store.timestamp()
    })
    # far but high semantic
    store.append_row('opportunities', {
        'id':'2','org_id':'1','title':'Advanced Math Teaching','description':'teach algebra','required_skills':'teaching math','tags':'education','schedule':'weekdays','latitude':'10.0','longitude':'10.0','created_at':store.timestamp()
    })


def test_ordering():
    recs = compute_recommendations('1', debug=True, limit=5)
    assert recs, 'No recommendations produced'
    # Expect the nearby math tutor to outrank the far high semantic due to geo weight
    assert recs[0]['opportunity_id'] == '1'
