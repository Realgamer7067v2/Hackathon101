# Signal-Sense

Prototype volunteer <> opportunity matcher using hybrid semantic + geospatial scoring. Lightweight CSV persistence with a clean service/storage separation to enable later RDBMS or vector store migration.

## Features
- Volunteer & Organization user types with separate registration/login
- Password hashing (Werkzeug) & session-based auth
- CSRF protection for all POST forms
- Volunteer profiles: skills, interests, availability, geolocation
- Organization opportunities: required skills, tags, schedule, geolocation
- Application workflow (single application per (volunteer, opportunity))
- Messaging threads per (volunteer, opportunity) pair
- Recommendation engine: custom TF-IDF + cosine + distance decay (Haversine)
- JSON recommendations endpoint with optional debug metrics
- Error handlers (400/403/404/500)
- Config-driven via environment variables (.env supported)
- Dockerized production entrypoint (gunicorn)
 - Modern responsive UI: dark/light theme toggle, hero landing page, feature cards, selectable skill/tag chips, animated flash messages, chat-style messaging threads, basic front-end validation

## Architecture Overview
Layered structure:
1. Web (Flask routes, templates) – `app.__init__`
2. Services – Recommendation logic (`app/services/recommendation.py`)
3. Storage – CSV abstraction (`app/storage/csv_storage.py`) exposing small surface (read, write, append, next_id, timestamp, find_by_id). All higher logic calls only these helpers; swapping to a DB means implementing compatible functions or a thin repository layer.
4. Auth utilities – hashing, decorators, CSRF (`app/auth/utils.py`).

## Recommendation Algorithm
1. Build volunteer text = skills + interests + availability
2. Opportunity text = title + description + required_skills + tags + schedule
3. Tokenize: lowercase; regex `[A-Za-z0-9][A-Za-z0-9-]*`
4. TF = term count / max term count in doc
5. IDF = log((N + 1)/(df + 1)) + 1
6. Weight = TF * IDF. Build sparse dict vectors.
7. Cosine similarity between volunteer and each opportunity vector
8. Distance (Haversine). Distance factor = 1 / (1 + dist_km/10)
9. If any coordinates missing -> neutral midpoint factor 0.75 (design choice for stable ranking)
10. Score = SEMANTIC_WEIGHT * cosine + GEO_WEIGHT * distance_factor
11. Sort descending, return top N
12. Debug mode adds: semantic, geo_factor, distance_km

## Environment Variables
| Name | Default | Description |
|------|---------|-------------|
| SECRET_KEY | (none in prod) | Flask session & CSRF secret |
| APP_ENV | dev | dev or prod (affects future toggles) |
| SEMANTIC_WEIGHT | 0.7 | Weight of semantic similarity |
| GEO_WEIGHT | 0.3 | Weight of geospatial factor |
| RECOMMENDATION_MAX_RESULTS | 10 | Default max recommendations |
| DATA_DIR | ./data | CSV storage directory |
| LOG_LEVEL | INFO | Logging verbosity |

See `.env.example` for a template.

## Data Files (CSV Schemas)
volunteers: id,name,email,password_hash,skills,interests,availability,latitude,longitude
organizations: id,name,email,password_hash,description,needs,latitude,longitude,verified
opportunities: id,org_id,title,description,required_skills,tags,schedule,latitude,longitude,created_at
applications: id,opportunity_id,volunteer_id,status,message,created_at
threads: id,opportunity_id,volunteer_id,org_id,created_at,updated_at
messages: id,thread_id,sender_type,sender_id,receiver_type,receiver_id,body,created_at
sessions: session_id,user_type,user_id,created_at (optional metrics)

## Quickstart (Dev)
```powershell
python -m venv .venv
./.venv/Scripts/Activate.ps1
pip install -r requirements.txt
copy .env.example .env  # then edit SECRET_KEY
python -m scripts.seed --force --yes  # preferred (adds proper package context)
python wsgi.py  # Flask dev server
```

Open: http://localhost:5000

## Running Tests
Example (pytest not bundled; for simple demonstration run via python -m pytest if installed). The included test file relies only on standard libs + project code. You may install pytest:
```powershell
pip install pytest
pytest -k recommendation
```

## Docker
```powershell
docker build -t signal-sense .
docker run -p 8000:8000 --env-file .env signal-sense
```
App served at http://localhost:8000

## Healthcheck
Simple: request `/` expecting 200.

## Seed Script
Preferred: `python -m scripts.seed --force --yes`

Direct execution `python scripts/seed.py` also works (adds project root to path automatically).

Flags:
- `--force --yes` wipe & reseed

## Test Scenario Walkthrough
1. Register a volunteer with skills matching an existing seeded opportunity.
2. Register an organization and create two opportunities (one aligned far, one partially aligned nearby).
3. Visit `/recommendations.json?volunteer_id=<id>&debug=1` to inspect score components.
4. Apply to one opportunity; a second application attempt is blocked.
5. Include an initial message in the application to auto-create a thread; exchange messages.
6. Confirm JSON includes distance_km, semantic, geo_factor when debug=1.
7. Interact with selectable chips on registration & opportunity forms to quickly populate structured fields.
8. Toggle light/dark theme using header control (persisted in localStorage).

## Security Notes
- Password hashing via Werkzeug (PBKDF2 / scrypt depending on version)
- CSRF token stored in session, validated on every POST
- Input sanitized (whitespace normalized, length capped)
- All user content auto-escaped by Jinja2
- Minimal dependencies reduces attack surface

## Performance & Extensibility
- Stateless tokenization & TF-IDF calculations (caching layer could be inserted later)
- Storage confined to `csv_storage`; swapping to SQL or vector DB requires minimal surface changes
- Distance factor constant (10) easily configurable for different locality sensitivity
- Opportunity for precomputing vectors & incremental updates in future

## Future Enhancements
- Relational DB migration (SQLAlchemy) & transactions
- Vector embeddings (e.g., sentence transformers) fallback with semantic cache
- Content moderation & validation pipelines
- Role-based permissions & admin verification workflow
- Rate limiting & audit logging
- Pagination for large lists
- WebSocket real-time messaging & presence
- Full-text + tag search indexing
- Precomputed TF-IDF caching or incremental index maintenance
 - Post-registration guided preference wizard (multi-step overlay) – partially scaffolded via chips; could capture fine-grained skill weighting

## License
PLACEHOLDER (Add your chosen license here)

