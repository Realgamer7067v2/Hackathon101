"""CSV storage abstraction with thread-safe operations.

Functions operate on CSV files located in the configured DATA_DIR. The intent is
that higher layers depend on these helpers so future migration to a database is
localized.
"""
from __future__ import annotations
import csv
import os
import threading
from typing import List, Dict, Iterable, Optional
from app.config import Config
from datetime import datetime

_LOCK = threading.Lock()

DATASETS = {
    'volunteers': ['id','name','email','password_hash','skills','interests','availability','latitude','longitude'],
    'organizations': ['id','name','email','password_hash','description','needs','latitude','longitude','verified'],
    'opportunities': ['id','org_id','title','description','required_skills','tags','schedule','latitude','longitude','created_at'],
    'applications': ['id','opportunity_id','volunteer_id','status','message','created_at'],
    'threads': ['id','opportunity_id','volunteer_id','org_id','created_at','updated_at'],
    'messages': ['id','thread_id','sender_type','sender_id','receiver_type','receiver_id','body','created_at'],
    'sessions': ['session_id','user_type','user_id','created_at'],
}

def ensure_data_dir():
    os.makedirs(Config.DATA_DIR, exist_ok=True)


def file_path(name: str) -> str:
    ensure_data_dir()
    return os.path.join(Config.DATA_DIR, f"{name}.csv")


def safe_init(name: str):
    path = file_path(name)
    if not os.path.exists(path):
        with _LOCK, open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=DATASETS[name])
            writer.writeheader()


def read_rows(name: str) -> List[Dict[str,str]]:
    """Read all rows for dataset name into list of dicts."""
    safe_init(name)
    path = file_path(name)
    with _LOCK, open(path, 'r', newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        return list(reader)


def write_rows(name: str, rows: Iterable[Dict[str,str]], fieldnames: Optional[Iterable[str]]=None):
    """Overwrite dataset with provided rows."""
    safe_init(name)
    path = file_path(name)
    fn = list(fieldnames) if fieldnames else DATASETS[name]
    with _LOCK, open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fn)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, '') for k in fn})


def append_row(name: str, row: Dict[str,str], fieldnames: Optional[Iterable[str]]=None):
    """Append a single row to dataset."""
    safe_init(name)
    path = file_path(name)
    fn = list(fieldnames) if fieldnames else DATASETS[name]
    with _LOCK, open(path, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fn)
        writer.writerow({k: row.get(k, '') for k in fn})


def next_id(rows: List[Dict[str,str]]) -> str:
    """Return next autoincrement string id from rows."""
    max_id = 0
    for r in rows:
        try:
            max_id = max(max_id, int(r['id']))
        except (ValueError, KeyError):
            continue
    return str(max_id + 1)


def timestamp() -> str:
    return datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')


def find_by_id(rows: List[Dict[str,str]], id_: str) -> Optional[Dict[str,str]]:
    for r in rows:
        if r.get('id') == id_:
            return r
    return None

