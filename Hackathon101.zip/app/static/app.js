// Basic interactivity: theme toggle, auto-load recommendations, flash auto-dismiss
(function(){
  const prefersLight = window.matchMedia('(prefers-color-scheme: light)').matches;
  const root = document.documentElement;
  const toggle = document.querySelector('[data-theme-toggle]');
  function setTheme(mode){
    if(mode==='light') root.classList.add('light'); else root.classList.remove('light');
    localStorage.setItem('theme', mode);
  }
  const saved = localStorage.getItem('theme');
  setTheme(saved || (prefersLight ? 'light':'dark'));
  toggle && toggle.addEventListener('click',()=>{
    const next = root.classList.contains('light') ? 'dark':'light';
    setTheme(next);
  });

  // flash auto dismiss
  setTimeout(()=>{
    document.querySelectorAll('.flash').forEach(f=>{f.style.opacity='0'; setTimeout(()=>f.remove(),600);});
  },5000);

  // volunteer dashboard recommendations fetch
  const recContainer = document.getElementById('recs');
  if(recContainer){
    const vid = recContainer.getAttribute('data-volunteer-id');
    if(vid){
      fetch(`/recommendations.json?volunteer_id=${vid}&debug=0`).then(r=>r.json()).then(data=>{
        if(!data.length){recContainer.innerHTML='<div class="muted">No matches yet.</div>';return;}
        recContainer.innerHTML='';
        data.forEach(rec=>{
          const d=document.createElement('div');
          d.className='rec';
            d.innerHTML=`<div><strong>${rec.title||'Opportunity '+rec.opportunity_id}</strong></div><div class="muted">Score: ${rec.score}</div><a class="btn secondary" href="/opportunity/${rec.opportunity_id}">View</a>`;
          recContainer.appendChild(d);
        });
      }).catch(()=>{recContainer.innerHTML='<div class="muted">Error loading recommendations.</div>';});
    }
  }

   // Selectable chips for predefined lists (skills / tags)
   const selectableGroups=document.querySelectorAll('[data-selectable-group]');
   selectableGroups.forEach(group=>{
       const targetId=group.getAttribute('data-target');
       const aggregate=(el)=>{
           const active=[...group.querySelectorAll('.selectable.active')].map(x=>x.getAttribute('data-value'));
           const tgt=document.getElementById(targetId);
           if(tgt){
               const existing=tgt.value.trim();
               const merged=[...new Set([...existing.split(/[,\s]+/).filter(Boolean),...active])];
               tgt.value=merged.join(', ');
           }
       };
       group.addEventListener('click',e=>{
           const chip=e.target.closest('.selectable');
           if(!chip) return;
           chip.classList.toggle('active');
           aggregate();
       });
   });

   // Basic front-end validation (non-intrusive)
   document.querySelectorAll('form').forEach(f=>{
     f.addEventListener('submit',e=>{
       const pw=f.querySelector('input[name=password]');
       if(pw && pw.value && pw.value.length<6){
         e.preventDefault();
         alert('Password must be at least 6 characters.');
         pw.focus();
         return;
       }
       // highlight empty required
       f.querySelectorAll('[required]').forEach(req=>{
         if(!req.value.trim()){
           req.classList.add('invalid');
         } else {
           req.classList.remove('invalid');
         }
       });
       if(f.querySelector('.invalid')){
         e.preventDefault();
         alert('Please fill all required fields.');
       }
     });
   });
})();