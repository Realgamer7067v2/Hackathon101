"""Recommendation engine: TF-IDF + distance decay."""
from __future__ import annotations
import math
import time
import logging
import re
from typing import Dict, List, Tuple
from app.config import Config
from app.storage.csv_storage import read_rows

logger = logging.getLogger(__name__)
TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9\-]*")


def tokenize(text: str) -> List[str]:
    text = text.lower()
    return TOKEN_RE.findall(text)


def build_doc(text: str) -> Dict[str, int]:
    counts: Dict[str,int] = {}
    for tok in tokenize(text):
        counts[tok] = counts.get(tok, 0) + 1
    return counts


def tfidf_vectors(docs: List[Dict[str,int]]) -> List[Dict[str,float]]:
    df: Dict[str,int] = {}
    for d in docs:
        for t in d:
            df[t] = df.get(t, 0) + 1
    N = len(docs)
    vectors: List[Dict[str,float]] = []
    for d in docs:
        if not d:
            vectors.append({})
            continue
        max_tf = max(d.values())
        v: Dict[str,float] = {}
        for t,c in d.items():
            tf = c / max_tf
            idf = math.log((N + 1) / (df[t] + 1)) + 1
            v[t] = tf * idf
        vectors.append(v)
    return vectors


def cosine(a: Dict[str,float], b: Dict[str,float]) -> float:
    if not a or not b:
        return 0.0
    dot = 0.0
    for t,wa in a.items():
        wb = b.get(t)
        if wb:
            dot += wa * wb
    na = math.sqrt(sum(v*v for v in a.values()))
    nb = math.sqrt(sum(v*v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c


def distance_factor(dist_km: float) -> float:
    return 1 / (1 + (dist_km / 10.0))


def build_volunteer_profile(vol: Dict[str,str]) -> str:
    return " ".join(filter(None, [vol.get('skills',''), vol.get('interests',''), vol.get('availability','')]))


def build_opportunity_text(opp: Dict[str,str]) -> str:
    return " ".join(filter(None, [opp.get('title',''), opp.get('description',''), opp.get('required_skills',''), opp.get('tags',''), opp.get('schedule','')]))


def compute_recommendations(volunteer_id: str, limit: int | None = None, debug: bool=False) -> List[Dict[str,object]]:
    start_time = time.time()
    volunteers = read_rows('volunteers')
    opportunities = read_rows('opportunities')

    vol = next((v for v in volunteers if v.get('id') == volunteer_id), None)
    if not vol:
        return []

    vol_text = build_volunteer_profile(vol)
    opp_texts = [build_opportunity_text(o) for o in opportunities]
    docs = [build_doc(vol_text)] + [build_doc(t) for t in opp_texts]
    vectors = tfidf_vectors(docs)
    v_vol = vectors[0]
    v_opps = vectors[1:]

    try:
        vlat = float(vol.get('latitude')) if vol.get('latitude') else None
        vlon = float(vol.get('longitude')) if vol.get('longitude') else None
    except ValueError:
        vlat = vlon = None

    recs: List[Tuple[float, Dict[str,object]]] = []
    for opp, vec in zip(opportunities, v_opps):
        sem = cosine(v_vol, vec)
        # geo
        try:
            olat = float(opp.get('latitude')) if opp.get('latitude') else None
            olon = float(opp.get('longitude')) if opp.get('longitude') else None
        except ValueError:
            olat = olon = None
        if vlat is not None and vlon is not None and olat is not None and olon is not None:
            dist = haversine(vlat, vlon, olat, olon)
            geo_fac = distance_factor(dist)
        else:
            dist = None
            geo_fac = 0.75  # neutral mid per spec if missing coords
        score = Config.SEMANTIC_WEIGHT * sem + Config.GEO_WEIGHT * geo_fac
        payload = {
            'opportunity_id': opp['id'],
            'title': opp.get('title'),
            'score': round(score,4),
        }
        if debug:
            payload.update({
                'semantic': round(sem,4),
                'geo_factor': round(geo_fac,4),
                'distance_km': round(dist,2) if dist is not None else None,
            })
        recs.append((score, payload))

    recs.sort(key=lambda x: x[0], reverse=True)
    max_results = limit or Config.RECOMMENDATION_MAX_RESULTS
    out = [p for _, p in recs[:max_results]]
    if debug:
        logger.info("recommendation debug volunteer=%s took=%.4fs", volunteer_id, time.time()-start_time)
    else:
        logger.info("recommendation request volunteer=%s", volunteer_id)
    return out
