"""Configuration and logging setup.

Provides a Config object loading environment variables with defaults and a
configure_logging helper to initialize application-wide logging early.
"""
import os
import logging
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change")
    APP_ENV = os.getenv("APP_ENV", "dev")
    SEMANTIC_WEIGHT = float(os.getenv("SEMANTIC_WEIGHT", "0.7"))
    GEO_WEIGHT = float(os.getenv("GEO_WEIGHT", "0.3"))
    RECOMMENDATION_MAX_RESULTS = int(os.getenv("RECOMMENDATION_MAX_RESULTS", "10"))
    DATA_DIR = os.getenv("DATA_DIR", "./data")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

    @classmethod
    def as_dict(cls):
        return {k: getattr(cls, k) for k in dir(cls) if k.isupper()}


def configure_logging():
    """Configure root logger based on config.

    Idempotent: if handlers already exist, does nothing.
    """
    if logging.getLogger().handlers:
        return
    level = getattr(logging, Config.LOG_LEVEL, logging.INFO)
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )

