"""Application factory and route registrations for Signal-Sense prototype."""
from __future__ import annotations
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, abort
import logging
from .config import Config, configure_logging
from .auth.utils import (
    login_user, logout_user, hash_password, verify_password, login_required,
    require_org, require_volunteer, csrf_token, csrf_protect, ensure_csrf_token
)
from .storage import csv_storage as store
from .services.recommendation import compute_recommendations

logger = logging.getLogger(__name__)


def create_app():
    configure_logging()
    app = Flask(__name__)
    app.config['SECRET_KEY'] = Config.SECRET_KEY
    app.jinja_env.globals['csrf_token'] = csrf_token

    # Ensure data files exist
    for name in store.DATASETS:
        store.safe_init(name)

    register_routes(app)
    register_errors(app)
    return app


def sanitize(text: str, limit: int | None = None) -> str:
    if text is None:
        return ''
    s = ' '.join(text.strip().split())
    if limit:
        return s[:limit]
    return s


def register_routes(app: Flask):
    @app.before_request
    def _set_csrf():
        if request.method == 'GET':
            ensure_csrf_token()

    @app.route('/')
    def index():
        volunteers = store.read_rows('volunteers')
        orgs = store.read_rows('organizations')
        opps = store.read_rows('opportunities')
        return render_template('index.html', stats={
            'volunteers': len(volunteers),
            'organizations': len(orgs),
            'opportunities': len(opps)
        })

    @app.route('/login', methods=['GET', 'POST'])
    @csrf_protect
    def login():
        if request.method == 'POST':
            email = sanitize(request.form.get('email','').lower())
            password = request.form.get('password','')
            user_type = request.form.get('user_type')
            if user_type not in ('volunteer','organization'):
                flash('Invalid user type')
                return redirect(url_for('login'))
            dataset = 'volunteers' if user_type=='volunteer' else 'organizations'
            rows = store.read_rows(dataset)
            found = next((r for r in rows if r.get('email') == email), None)
            if not found or not verify_password(found.get('password_hash',''), password):
                logger.info('login failure email=%s type=%s', email, user_type)
                flash('Invalid credentials')
                return redirect(url_for('login'))
            login_user(user_type, found['id'])
            logger.info('login success user_type=%s id=%s', user_type, found['id'])
            return redirect(url_for('dashboard_volunteer' if user_type=='volunteer' else 'dashboard_org'))
        return render_template('login.html')

    @app.route('/logout')
    def logout():
        logout_user()
        flash('Logged out')
        return redirect(url_for('index'))

    @app.route('/register/volunteer', methods=['GET','POST'])
    @csrf_protect
    def register_volunteer():
        if request.method == 'POST':
            rows = store.read_rows('volunteers')
            email = sanitize(request.form.get('email','').lower())
            if any(r.get('email') == email for r in rows):
                flash('Email already registered')
                return redirect(url_for('register_volunteer'))
            vid = store.next_id(rows)
            row = {
                'id': vid,
                'name': sanitize(request.form.get('name','')),
                'email': email,
                'password_hash': hash_password(request.form.get('password','')),
                'skills': sanitize(request.form.get('skills','')),
                'interests': sanitize(request.form.get('interests','')),
                'availability': sanitize(request.form.get('availability','')),
                'latitude': sanitize(request.form.get('latitude','')),
                'longitude': sanitize(request.form.get('longitude','')),
            }
            store.append_row('volunteers', row)
            logger.info('volunteer registered id=%s email=%s', vid, email)
            flash('Registered. Please login.')
            return redirect(url_for('login'))
        return render_template('register_volunteer.html')

    @app.route('/register/org', methods=['GET','POST'])
    @csrf_protect
    def register_org():
        if request.method == 'POST':
            rows = store.read_rows('organizations')
            email = sanitize(request.form.get('email','').lower())
            if any(r.get('email') == email for r in rows):
                flash('Email already registered')
                return redirect(url_for('register_org'))
            oid = store.next_id(rows)
            row = {
                'id': oid,
                'name': sanitize(request.form.get('name','')),
                'email': email,
                'password_hash': hash_password(request.form.get('password','')),
                'description': sanitize(request.form.get('description','')),
                'needs': sanitize(request.form.get('needs','')),
                'latitude': sanitize(request.form.get('latitude','')),
                'longitude': sanitize(request.form.get('longitude','')),
                'verified': '1',
            }
            store.append_row('organizations', row)
            logger.info('organization registered id=%s email=%s', oid, email)
            flash('Organization registered. Please login.')
            return redirect(url_for('login'))
        return render_template('register_org.html')

    @app.route('/dashboard/volunteer')
    @login_required
    @require_volunteer
    def dashboard_volunteer():
        vids = session.get('user_id')
        applications = [a for a in store.read_rows('applications') if a.get('volunteer_id') == vids]
        opportunities = {o['id']: o for o in store.read_rows('opportunities')}
        volunteer = next((v for v in store.read_rows('volunteers') if v.get('id') == vids), None)
        return render_template('dashboard_volunteer.html', volunteer=volunteer, applications=applications, opportunities=opportunities)

    @app.route('/dashboard/org')
    @login_required
    @require_org
    def dashboard_org():
        oid = session.get('user_id')
        opportunities = [o for o in store.read_rows('opportunities') if o.get('org_id') == oid]
        apps = store.read_rows('applications')
        apps_by_opp = {}
        for a in apps:
            if a.get('opportunity_id') in [o['id'] for o in opportunities]:
                apps_by_opp.setdefault(a.get('opportunity_id'), []).append(a)
        return render_template('dashboard_org.html', opportunities=opportunities, applications=apps_by_opp)

    @app.route('/opportunity/new', methods=['GET','POST'])
    @login_required
    @require_org
    @csrf_protect
    def opportunity_new():
        if request.method == 'POST':
            rows = store.read_rows('opportunities')
            oid = session.get('user_id')
            title = sanitize(request.form.get('title',''), 200)
            desc = sanitize(request.form.get('description',''), 5000)
            opp_id = store.next_id(rows)
            row = {
                'id': opp_id,
                'org_id': oid,
                'title': title,
                'description': desc,
                'required_skills': sanitize(request.form.get('required_skills','')),
                'tags': sanitize(request.form.get('tags','')),
                'schedule': sanitize(request.form.get('schedule','')),
                'latitude': sanitize(request.form.get('latitude','')),
                'longitude': sanitize(request.form.get('longitude','')),
                'created_at': store.timestamp(),
            }
            store.append_row('opportunities', row)
            logger.info('opportunity created id=%s org=%s', opp_id, oid)
            flash('Opportunity created')
            return redirect(url_for('opportunity_view', id=opp_id))
        return render_template('opportunity_new.html')

    @app.route('/opportunity/<id>')
    def opportunity_view(id):
        opps = store.read_rows('opportunities')
        opp = next((o for o in opps if o.get('id') == id), None)
        if not opp:
            abort(404)
        org = next((o for o in store.read_rows('organizations') if o.get('id') == opp.get('org_id')), None)
        return render_template('opportunity_view.html', opp=opp, org=org)

    @app.route('/opportunity/<id>/apply', methods=['POST'])
    @login_required
    @require_volunteer
    @csrf_protect
    def opportunity_apply(id):
        opps = store.read_rows('opportunities')
        if not any(o.get('id') == id for o in opps):
            abort(404)
        vid = session.get('user_id')
        apps = store.read_rows('applications')
        if any(a.get('opportunity_id') == id and a.get('volunteer_id') == vid for a in apps):
            flash('Already applied.')
            return redirect(url_for('opportunity_view', id=id))
        app_id = store.next_id(apps)
        message = sanitize(request.form.get('message',''))
        row = {
            'id': app_id,
            'opportunity_id': id,
            'volunteer_id': vid,
            'status': 'pending',
            'message': message,
            'created_at': store.timestamp(),
        }
        store.append_row('applications', row)
        logger.info('application submitted id=%s opp=%s vol=%s', app_id, id, vid)
        # thread creation logic if message
        if message:
            threads = store.read_rows('threads')
            t_id = store.next_id(threads)
            trow = {
                'id': t_id,
                'opportunity_id': id,
                'volunteer_id': vid,
                'org_id': next((o.get('org_id') for o in opps if o.get('id')==id), ''),
                'created_at': store.timestamp(),
                'updated_at': store.timestamp(),
            }
            store.append_row('threads', trow)
            messages = store.read_rows('messages')
            m_id = store.next_id(messages)
            mrow = {
                'id': m_id,
                'thread_id': t_id,
                'sender_type': 'volunteer',
                'sender_id': vid,
                'receiver_type': 'organization',
                'receiver_id': trow['org_id'],
                'body': message,
                'created_at': store.timestamp(),
            }
            store.append_row('messages', mrow)
        flash('Application submitted')
        return redirect(url_for('opportunity_view', id=id))

    @app.route('/recommendations.json')
    def recommendations_json():
        volunteer_id = request.args.get('volunteer_id')
        if not volunteer_id:
            return jsonify([])
        limit = request.args.get('limit')
        debug = request.args.get('debug') == '1'
        try:
            lim = int(limit) if limit else None
        except ValueError:
            lim = None
        recs = compute_recommendations(volunteer_id, lim, debug)
        return jsonify(recs)

    @app.route('/thread/<id>')
    @login_required
    def thread_view(id):
        threads = store.read_rows('threads')
        t = next((th for th in threads if th.get('id') == id), None)
        if not t:
            abort(404)
        user_type = session.get('user_type')
        user_id = session.get('user_id')
        if not ((user_type=='volunteer' and t.get('volunteer_id')==user_id) or (user_type=='organization' and t.get('org_id')==user_id)):
            abort(403)
        messages = [m for m in store.read_rows('messages') if m.get('thread_id') == id]
        messages.sort(key=lambda m: m.get('created_at'))
        return render_template('thread_view.html', thread=t, messages=messages)

    @app.route('/thread/<id>/message', methods=['POST'])
    @login_required
    @csrf_protect
    def thread_message(id):
        threads = store.read_rows('threads')
        t = next((th for th in threads if th.get('id') == id), None)
        if not t:
            abort(404)
        user_type = session.get('user_type')
        user_id = session.get('user_id')
        if not ((user_type=='volunteer' and t.get('volunteer_id')==user_id) or (user_type=='organization' and t.get('org_id')==user_id)):
            abort(403)
        body = sanitize(request.form.get('body',''))
        if body:
            messages = store.read_rows('messages')
            m_id = store.next_id(messages)
            receiver_type = 'organization' if user_type=='volunteer' else 'volunteer'
            receiver_id = t.get('org_id') if receiver_type=='organization' else t.get('volunteer_id')
            mrow = {
                'id': m_id,
                'thread_id': id,
                'sender_type': user_type,
                'sender_id': user_id,
                'receiver_type': receiver_type,
                'receiver_id': receiver_id,
                'body': body,
                'created_at': store.timestamp(),
            }
            store.append_row('messages', mrow)
            logger.info('message posted thread=%s sender=%s:%s', id, user_type, user_id)
        return redirect(url_for('thread_view', id=id))


def register_errors(app: Flask):
    @app.errorhandler(400)
    def bad_request(e):
        return render_template('400.html'), 400
    @app.errorhandler(403)
    def forbidden(e):
        return render_template('403.html'), 403
    @app.errorhandler(404)
    def not_found(e):
        return render_template('404.html'), 404
    @app.errorhandler(500)
    def server_error(e):
        return render_template('500.html'), 500

