"""Authentication and authorization utilities: hashing, decorators, CSRF."""
from functools import wraps
from flask import session, redirect, url_for, flash, request, abort
from werkzeug.security import generate_password_hash, check_password_hash
import secrets

CSRF_SESSION_KEY = '_csrf_token'


def hash_password(password: str) -> str:
    return generate_password_hash(password)


def verify_password(pw_hash: str, candidate: str) -> bool:
    return check_password_hash(pw_hash, candidate)


def get_current_user():
    return session.get('user_type'), session.get('user_id')


def login_user(user_type: str, user_id: str):
    session['user_type'] = user_type
    session['user_id'] = user_id
    ensure_csrf_token()


def logout_user():
    session.pop('user_type', None)
    session.pop('user_id', None)
    session.pop(CSRF_SESSION_KEY, None)


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in first.')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return wrapper


def require_volunteer(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('user_type') != 'volunteer':
            abort(403)
        return f(*args, **kwargs)
    return wrapper


def require_org(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get('user_type') != 'organization':
            abort(403)
        return f(*args, **kwargs)
    return wrapper


def ensure_csrf_token():
    if CSRF_SESSION_KEY not in session:
        session[CSRF_SESSION_KEY] = secrets.token_hex(16)
    return session[CSRF_SESSION_KEY]


def validate_csrf():
    token = session.get(CSRF_SESSION_KEY)
    form_token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
    if not token or not form_token or token != form_token:
        abort(400)


def csrf_protect(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if request.method == 'POST':
            validate_csrf()
        return f(*args, **kwargs)
    return wrapper


def csrf_token():  # exposed to templates
    return ensure_csrf_token()
